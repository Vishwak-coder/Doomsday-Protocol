import { createClient } from '@supabase/supabase-js'
const url=import.meta.env.VITE_SUPABASE_URL as string|undefined
const key=import.meta.env.VITE_SUPABASE_PUBLISHABLE_KEY as string|undefined
// Missing env vars must never crash the app at import time (createClient throws on an empty URL).
export const isConfigured=Boolean(url&&key)
export const supabase=createClient(url||'https://placeholder.supabase.co',key||'placeholder-key')
