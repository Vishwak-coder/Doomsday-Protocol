import { supabase } from './supabase'
// Calls OUR server (api/vishwa.ts); the Gemini key never reaches the browser.
export async function askVishwa(message:string,history:{role:'user'|'model';text:string}[]){
 const{data:{session}}=await supabase.auth.getSession()
 const r=await fetch('/api/vishwa',{method:'POST',headers:{'Content-Type':'application/json',Authorization:`Bearer ${session?.access_token}`},body:JSON.stringify({message,history})})
 if(!r.ok)throw new Error('VISHWA offline');return (await r.json()).reply as string}
