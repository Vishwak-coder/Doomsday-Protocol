import { supabase } from './supabase'
export async function loadProgress(uid:string){const{data}=await supabase.from('watch_progress').select('content_id').eq('user_id',uid).eq('completed',true);return new Set((data??[]).map(r=>r.content_id as string))}
export async function setCompleted(uid:string,id:string,on:boolean){
 const q=on?supabase.from('watch_progress').upsert({user_id:uid,content_id:id,completed:true,completed_at:new Date().toISOString()},{onConflict:'user_id,content_id'}):supabase.from('watch_progress').delete().eq('user_id',uid).eq('content_id',id)
 const{error}=await q;if(error)throw error
 await supabase.from('activity_logs').insert({user_id:uid,activity_type:on?'completed':'uncompleted',content_id:id})}
