import { BrowserRouter, Routes, Route, NavLink } from 'react-router-dom'
import { AuthProvider, useAuth } from './hooks/useAuth'
import { useProgress } from './hooks/useProgress'
import { useRole } from './hooks/useRole'
import { supabase, isConfigured } from './services/supabase'
import { readiness } from './utils/readiness'
import Home from './pages/Home'; import Timeline from './pages/Timeline'; import Login from './pages/Login'; import AdminDashboard from './pages/AdminDashboard'
import AIChat from './components/AIChat'; import Logo from './components/Logo'; import Intro from './components/Intro'; import Complete from './components/Complete'; import ProtectedRoute from './components/ProtectedRoute'
const link=({isActive}:{isActive:boolean})=>isActive?'text-brand font-medium':'text-stone-500 hover:text-ink'
function ConfigNotice(){return <div className="min-h-screen grid place-items-center p-6"><div className="glass p-6 max-w-lg space-y-3"><div className="flex items-center gap-2 font-display text-lg"><Logo/>DOOMSDAY PROTOCOL</div><p className="font-medium">Configuration required</p><p className="text-sm text-stone-600">Set <code>VITE_SUPABASE_URL</code> and <code>VITE_SUPABASE_PUBLISHABLE_KEY</code> in your Vercel project (Settings, Environment Variables), then redeploy. Vite reads these at build time.</p></div></div>}
function Shell(){
 const{user,loading}=useAuth(),{done,toggle,toast}=useProgress(),role=useRole(user)
 if(loading)return <Intro/>
 if(!user)return <><Intro/><Login/></>
 return <div className="max-w-4xl mx-auto p-4"><Intro/>{readiness(done).overall===100&&<Complete/>}
  <nav className="flex gap-5 items-center mb-8 pb-3 border-b border-black/10 text-sm"><span className="flex items-center gap-2 font-display text-ink"><Logo/>DOOMSDAY PROTOCOL</span>
   <NavLink to="/" end className={link}>Dashboard</NavLink><NavLink to="/timeline" className={link}>Timeline</NavLink>{role==='admin'&&<NavLink to="/admin" className={link}>Admin</NavLink>}
   <button className="ml-auto text-stone-500 hover:text-ink" onClick={()=>supabase.auth.signOut()}>Log out</button></nav>
  <Routes><Route path="/" element={<Home done={done} name={user.user_metadata?.display_name??user.email??''}/>}/><Route path="/timeline" element={<Timeline done={done} toggle={toggle}/>}/>
   <Route path="/admin" element={<ProtectedRoute allowed={role==='admin'}><AdminDashboard/></ProtectedRoute>}/></Routes>
  {toast&&<div className="fixed top-4 right-4 glass px-4 py-2 text-brand text-sm shadow-md">{toast}</div>}<AIChat/></div>}
export default function App(){if(!isConfigured)return <ConfigNotice/>;return <BrowserRouter><AuthProvider><Shell/></AuthProvider></BrowserRouter>}
