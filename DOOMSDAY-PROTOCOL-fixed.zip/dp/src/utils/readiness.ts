import { MCU } from '../data/mcu'
export const LEVELS=[[0,'MULTIVERSE NEWCOMER'],[21,'HERO IN TRAINING'],[41,'AVENGERS RECRUIT'],[61,'MULTIVERSE DEFENDER'],[81,'DOOMSDAY SPECIALIST']] as const
export function readiness(done:Set<string>){
 const rel=MCU.filter(e=>e.status==='released'),ess=rel.filter(e=>e.imp==='ESSENTIAL')
 const pct=(l:typeof rel)=>l.length?Math.round(100*l.filter(e=>done.has(e.id)).length/l.length):0
 const overall=pct(rel),essential=pct(ess)
 const level=overall===100?'DOOMSDAY READY':[...LEVELS].reverse().find(l=>overall>=l[0])![1]
 return {overall,essential,level,remaining:rel.filter(e=>!done.has(e.id)).length,
  movies:rel.filter(e=>e.type==='movie'&&done.has(e.id)).length,shows:rel.filter(e=>e.type!=='movie'&&done.has(e.id)).length}}
