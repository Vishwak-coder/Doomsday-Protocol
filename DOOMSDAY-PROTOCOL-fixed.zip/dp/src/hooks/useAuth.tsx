import { createContext, useContext, useEffect, useState, ReactNode } from 'react'
import type { User } from '@supabase/supabase-js'
import { supabase } from '../services/supabase'
const Ctx=createContext<{user:User|null;loading:boolean}>({user:null,loading:true})
export const useAuth=()=>useContext(Ctx)
export function AuthProvider({children}:{children:ReactNode}){
 const[user,setUser]=useState<User|null>(null),[loading,setLoading]=useState(true)
 useEffect(()=>{supabase.auth.getSession().then(({data})=>setUser(data.session?.user??null)).catch(()=>setUser(null)).finally(()=>setLoading(false))
  const{data:s}=supabase.auth.onAuthStateChange((e,sess)=>{setUser(sess?.user??null);if(e==='SIGNED_IN')supabase.rpc('touch_login')})
  return()=>s.subscription.unsubscribe()},[])
 return <Ctx.Provider value={{user,loading}}>{children}</Ctx.Provider>}
