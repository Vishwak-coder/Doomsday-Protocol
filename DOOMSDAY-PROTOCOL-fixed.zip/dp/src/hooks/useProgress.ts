import { useCallback, useEffect, useState } from 'react'
import { useAuth } from './useAuth'
import { loadProgress, setCompleted } from '../services/progress'
export function useProgress(){
 const{user}=useAuth(),[done,setDone]=useState<Set<string>>(new Set()),[toast,setToast]=useState('')
 useEffect(()=>{if(user)loadProgress(user.id).then(setDone)},[user])
 const toggle=useCallback(async(id:string,title:string)=>{if(!user)return
  const on=!done.has(id),prev=done,n=new Set(done);on?n.add(id):n.delete(id);setDone(n)
  try{await setCompleted(user.id,id,on);if(on){setToast(`MISSION LOGGED: ${title}`);setTimeout(()=>setToast(''),2500)}}catch{setDone(prev)}},[user,done])
 return{done,toggle,toast}}
