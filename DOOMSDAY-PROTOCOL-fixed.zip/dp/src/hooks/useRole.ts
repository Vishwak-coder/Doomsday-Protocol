import { useEffect, useState } from 'react'
import type { User } from '@supabase/supabase-js'
import { supabase } from '../services/supabase'
export function useRole(user:User|null){const[role,setRole]=useState<string|null>(null)
 useEffect(()=>{if(!user){setRole(null);return};supabase.from('profiles').select('role').eq('id',user.id).single().then(({data})=>setRole(data?.role??'user'))},[user])
 return role}
