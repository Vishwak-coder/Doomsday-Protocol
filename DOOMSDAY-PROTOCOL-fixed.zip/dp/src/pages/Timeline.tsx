import { useMemo, useState } from 'react'
import { MCU } from '../data/mcu'
import MovieCard from '../components/MovieCard'
const F=['All','Movies','Series','Specials','Animation','Essential','Recommended','Completed','Remaining']
export default function Timeline({done,toggle}:{done:Set<string>;toggle:(id:string,t:string)=>void}){
 const[f,setF]=useState('All'),[q,setQ]=useState(''),[rel,setRel]=useState(false)
 const list=useMemo(()=>MCU.filter(e=>({All:1,Movies:e.type==='movie',Series:e.type==='series',Specials:e.type==='special',Animation:e.type==='animation',Essential:e.imp==='ESSENTIAL',Recommended:e.imp==='RECOMMENDED',Completed:done.has(e.id),Remaining:!done.has(e.id)}as any)[f]&&e.title.toLowerCase().includes(q.toLowerCase())).sort((a,b)=>rel?a.year-b.year||a.order-b.order:a.order-b.order),[f,q,rel,done])
 let last=''
 return <div className="space-y-3"><div className="flex flex-wrap gap-2">{F.map(x=><button key={x} onClick={()=>setF(x)} className={`px-3 py-1 rounded-full text-sm glass ${f===x?'bg-brand text-white':''}`}>{x}</button>)}
  <input value={q} onChange={e=>setQ(e.target.value)} placeholder="Search…" className="glass px-3 py-1 bg-transparent"/>
  <button onClick={()=>setRel(!rel)} className="glass px-3 py-1 text-sm">{rel?'Release order':'Story order'}</button></div>
  {list.map(e=>{const h=!rel&&e.eras!==last?(last=e.eras):null
   return <div key={e.id}>{h&&<h2 className="font-display text-brand mt-6 mb-2">{h}</h2>}<MovieCard e={e} done={done.has(e.id)} onToggle={()=>toggle(e.id,e.title)}/></div>})}</div>}
