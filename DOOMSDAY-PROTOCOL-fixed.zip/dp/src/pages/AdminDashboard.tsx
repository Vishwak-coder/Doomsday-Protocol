import { useEffect, useMemo, useState } from 'react'
import { Bar, BarChart, ResponsiveContainer, Tooltip, XAxis, YAxis } from 'recharts'
import { supabase } from '../services/supabase'
import { MCU } from '../data/mcu'
type U={user_id:string;display_name:string;created_at:string;last_login_at:string|null;completed:number;essential_completed:number}
const REL=MCU.filter(e=>e.status==='released'),ESS=REL.filter(e=>e.imp==='ESSENTIAL')
const d=(s:string|null)=>s?new Date(s).toLocaleDateString():'Never'
export default function AdminDashboard(){
 const[users,setUsers]=useState<U[]>([]),[counts,setCounts]=useState<Record<string,number>>({}),[q,setQ]=useState(''),[err,setErr]=useState('')
 useEffect(()=>{Promise.all([supabase.rpc('admin_overview'),supabase.rpc('admin_title_counts')]).then(([a,b])=>{if(a.error||b.error)return setErr('Admin data unavailable');setUsers(a.data??[]);setCounts(Object.fromEntries((b.data??[]).map((r:any)=>[r.content_id,Number(r.n)])))})},[])
 const pct=(n:number,t:number)=>Math.round(100*Number(n)/t)
 const avg=users.length?Math.round(users.reduce((s,u)=>s+pct(u.completed,REL.length),0)/users.length):0
 const active=users.filter(u=>u.last_login_at&&Date.now()-+new Date(u.last_login_at)<6048e5).length
 const ranked=useMemo(()=>REL.map(e=>({title:e.title,n:counts[e.id]??0})).sort((a,b)=>b.n-a.n),[counts])
 const rows=users.filter(u=>u.display_name.toLowerCase().includes(q.toLowerCase()))
 if(err)return <p className="text-brand">{err}</p>
 return <div className="space-y-6"><h1 className="font-display text-3xl">Command Center</h1>
  <div className="grid grid-cols-3 gap-3">{[['Registered users',users.length],['Average readiness',avg+'%'],['Active (7 days)',active]].map(([l,v])=><div key={l} className="glass p-4"><p className="text-xs text-stone-500">{l}</p><p className="font-display text-3xl text-brand">{v}</p></div>)}</div>
  <div className="glass p-4"><h2 className="font-display mb-2">Most completed titles</h2><div style={{height:260}}><ResponsiveContainer><BarChart data={ranked.slice(0,8)} layout="vertical" margin={{left:60}}><XAxis type="number" allowDecimals={false}/><YAxis type="category" dataKey="title" width={150} tick={{fontSize:11}}/><Tooltip/><Bar dataKey="n" fill="#2f6f4e" radius={3}/></BarChart></ResponsiveContainer></div>
   <p className="text-xs text-stone-500 mt-2">Least completed: {ranked.slice(-5).map(r=>`${r.title} (${r.n})`).join(', ')}</p></div>
  <div className="glass p-4 overflow-x-auto"><input value={q} onChange={e=>setQ(e.target.value)} placeholder="Search users…" className="glass px-3 py-1 mb-3"/>
   <table className="w-full text-sm"><thead className="text-left text-stone-500"><tr><th>User</th><th>Registered</th><th>Last login</th><th>Readiness</th><th>Essential</th></tr></thead>
   <tbody>{rows.map(u=><tr key={u.user_id} className="border-t border-black/5"><td className="py-2">{u.display_name}</td><td>{d(u.created_at)}</td><td>{d(u.last_login_at)}</td><td>{pct(u.completed,REL.length)}%</td><td>{pct(u.essential_completed,ESS.length)}%</td></tr>)}</tbody></table></div></div>}
