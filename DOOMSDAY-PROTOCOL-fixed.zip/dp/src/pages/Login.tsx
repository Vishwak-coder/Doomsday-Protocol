import { useState } from 'react'
import { supabase } from '../services/supabase'
export default function Login(){
 const[reg,setReg]=useState(false),[email,setE]=useState(''),[pw,setP]=useState(''),[name,setN]=useState(''),[msg,setMsg]=useState('')
 const go=async()=>{const r=reg?await supabase.auth.signUp({email,password:pw,options:{data:{display_name:name}}}):await supabase.auth.signInWithPassword({email,password:pw});setMsg(r.error?.message??(reg?'Check your email to confirm.':''))}
 const reset=async()=>{await supabase.auth.resetPasswordForEmail(email);setMsg('Reset email sent if the account exists.')}
 const c="glass w-full px-3 py-2 bg-transparent"
 return <div className="min-h-screen grid place-items-center p-4"><div className="glass p-6 w-96 space-y-3"><h1 className="font-display text-xl text-center">DOOMSDAY PROTOCOL</h1>
  {reg&&<input className={c} placeholder="Display name" value={name} onChange={e=>setN(e.target.value)}/>}
  <input className={c} placeholder="Email" value={email} onChange={e=>setE(e.target.value)}/><input className={c} type="password" placeholder="Password" value={pw} onChange={e=>setP(e.target.value)}/>
  <button onClick={go} className="w-full bg-brand text-white rounded py-2">{reg?'Register':'Login'}</button>
  <div className="flex justify-between text-xs text-stone-500"><button onClick={()=>setReg(!reg)}>{reg?'Have an account?':'Create account'}</button><button onClick={reset}>Forgot password</button></div><p className="text-xs text-brand">{msg}</p></div></div>}
