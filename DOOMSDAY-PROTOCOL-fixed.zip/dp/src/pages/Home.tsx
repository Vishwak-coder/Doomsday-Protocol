import { MCU } from '../data/mcu'
import { readiness } from '../utils/readiness'
import ProgressRing from '../components/ProgressRing'
export default function Home({done,name}:{done:Set<string>;name:string}){
 const r=readiness(done),next=MCU.find(e=>e.status==='released'&&!done.has(e.id)&&e.imp==='ESSENTIAL')??MCU.find(e=>e.status==='released'&&!done.has(e.id))
 return <div className="space-y-6"><p className="text-stone-500">Welcome, {name}.</p>
 <h1 className="font-display text-2xl md:text-4xl">THE MULTIVERSE IS WAITING. ARE YOU READY?</h1>
 <div className="glass p-6 flex flex-wrap items-center gap-8"><ProgressRing value={r.overall}/>
  <div><p className="font-display text-brand">{r.level}</p><p>Essential storyline: <b>{r.essential}%</b></p><p>Movies {r.movies} · Shows {r.shows} · Remaining {r.remaining}</p>
  <p className="text-xs text-stone-500 mt-2">Measures watchlist completion, not understanding. Unreleased titles excluded.</p></div></div>
 {next?<div className="glass p-4"><p className="text-xs text-stone-500">NEXT RECOMMENDED</p><p className="font-semibold">{next.title}</p></div>:<h2 className="font-display text-2xl text-brand">YOU ARE READY.</h2>}</div>}
