import { useState } from 'react'
import { Bot, X } from 'lucide-react'
import { askVishwa } from '../services/gemini'
type M={role:'user'|'model';text:string}
const SUG=['What should I watch next?','Explain the Infinity Stones','What is the Multiverse?']
export default function AIChat(){
 const[open,setOpen]=useState(false),[msgs,setMsgs]=useState<M[]>([]),[v,setV]=useState(''),[busy,setBusy]=useState(false)
 const send=async(t:string)=>{if(!t.trim()||busy)return;const h=msgs;setMsgs([...h,{role:'user',text:t}]);setV('');setBusy(true)
  try{const reply=await askVishwa(t,h);setMsgs(m=>[...m,{role:'model',text:reply}])}catch{setMsgs(m=>[...m,{role:'model',text:'VISHWA is offline. Check server configuration.'}])}setBusy(false)}
 return <>{!open&&<button onClick={()=>setOpen(true)} className="fixed bottom-5 right-5 h-14 w-14 rounded-full bg-brand text-white grid place-items-center shadow-md text-white" aria-label="Open VISHWA"><Bot/></button>}
 {open&&<div className="glass fixed bottom-5 right-5 w-[22rem] max-w-[92vw] h-[28rem] flex flex-col bg-white shadow-xl">
  <div className="p-3 flex justify-between border-b border-black/10"><b className="font-display">VISHWA</b><button onClick={()=>setOpen(false)}><X size={18}/></button></div>
  <div className="flex-1 overflow-auto p-3 space-y-2 text-sm">{!msgs.length&&SUG.map(s=><button key={s} onClick={()=>send(s)} className="glass block px-2 py-1 text-left">{s}</button>)}
   {msgs.map((m,i)=><p key={i} className={m.role==='user'?'text-right text-brand':''}>{m.text}</p>)}{busy&&<p className="animate-pulse text-stone-500">VISHWA is thinking…</p>}</div>
  <form onSubmit={e=>{e.preventDefault();send(v)}} className="p-2 flex gap-2"><input value={v} onChange={e=>setV(e.target.value)} className="flex-1 glass bg-transparent px-2" placeholder="Ask VISHWA…"/></form></div>}</>}
