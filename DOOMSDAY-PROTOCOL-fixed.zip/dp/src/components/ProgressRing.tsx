import { motion } from 'framer-motion'
export default function ProgressRing({value,size=180}:{value:number;size?:number}){const r=size/2-10,c=2*Math.PI*r
 return <svg width={size} height={size}><circle cx={size/2} cy={size/2} r={r} stroke="#dfe8e1" strokeWidth="10" fill="none"/>
 <motion.circle cx={size/2} cy={size/2} r={r} stroke="#2f6f4e" strokeWidth="10" fill="none" strokeLinecap="round" strokeDasharray={c} initial={{strokeDashoffset:c}} animate={{strokeDashoffset:c*(1-value/100)}} transition={{duration:1.2}} transform={`rotate(-90 ${size/2} ${size/2})`} />
 <text x="50%" y="50%" textAnchor="middle" dy=".35em" fill="#14301f" fontSize="32" fontFamily="Fraunces, Georgia, serif">{value}%</text></svg>}
