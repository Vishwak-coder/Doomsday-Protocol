import { Navigate } from 'react-router-dom'
import type { ReactNode } from 'react'
// UI gate only. Real enforcement is Postgres RLS + admin_* functions.
export default function ProtectedRoute({allowed,children}:{allowed:boolean;children:ReactNode}){return allowed?<>{children}</>:<Navigate to="/" replace/>}
