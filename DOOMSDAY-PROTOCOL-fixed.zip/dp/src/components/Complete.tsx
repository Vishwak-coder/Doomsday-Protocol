import { useState } from 'react'
import { Award } from 'lucide-react'
export default function Complete(){const[open,setOpen]=useState(true);if(!open)return null
 return <div className="fixed inset-0 z-50 grid place-items-center bg-ink/95 text-paper text-center p-6"><div className="space-y-4 max-w-xl">
  <Award className="mx-auto text-emerald-300" size={56}/><h1 className="font-display text-3xl md:text-5xl">DOOMSDAY PROTOCOL COMPLETE</h1>
  <p className="tracking-widest text-emerald-200 text-sm">EVERY STORY. EVERY HERO. ONE FINAL BATTLE.</p><p className="font-display text-4xl">YOU ARE READY.</p>
  <button onClick={()=>setOpen(false)} className="mt-4 px-5 py-2 rounded-full bg-emerald-400 text-ink font-medium">Continue</button></div></div>}
