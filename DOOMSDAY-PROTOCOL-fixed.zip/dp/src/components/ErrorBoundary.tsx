import { Component, ReactNode } from 'react'
export default class ErrorBoundary extends Component<{children:ReactNode},{err:Error|null}>{
 state={err:null as Error|null}
 static getDerivedStateFromError(err:Error){return{err}}
 componentDidCatch(err:Error){console.error('DOOMSDAY PROTOCOL runtime error:',err)}
 render(){return this.state.err?<div className="min-h-screen grid place-items-center p-6 text-center"><div className="glass p-6 max-w-md space-y-2"><h1 className="font-display text-xl">DOOMSDAY PROTOCOL hit a snag</h1><p className="text-sm text-stone-600">{this.state.err.message}</p><button className="px-4 py-2 rounded bg-brand text-white" onClick={()=>location.reload()}>Reload</button></div></div>:this.props.children}}
