import { useEffect, useState } from 'react'
import Logo from './Logo'
export default function Intro(){
 const[step,setStep]=useState(sessionStorage.getItem('dp-intro')?3:0)
 useEffect(()=>{if(step>=3)return;const t=setTimeout(()=>{setStep(step+1);if(step===2)sessionStorage.setItem('dp-intro','1')},step===2?900:1300);return()=>clearTimeout(t)},[step])
 if(step>=3)return null
 return <div className="fixed inset-0 z-50 grid place-items-center bg-paper text-center transition-opacity"><div className="space-y-3"><div className="grid place-items-center"><Logo size={56}/></div>
  <p className="font-display text-lg">INITIALIZING DOOMSDAY PROTOCOL...</p><p className={`text-sm text-brand tracking-widest transition-opacity ${step>0?'opacity-100':'opacity-0'}`}>VISHWA INTELLIGENCE SYSTEM ONLINE.</p></div></div>}
