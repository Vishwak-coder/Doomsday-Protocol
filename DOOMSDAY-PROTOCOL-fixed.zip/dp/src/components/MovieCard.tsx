import { motion } from 'framer-motion'
import type { Entry } from '../data/mcu'
const col={ESSENTIAL:'text-brand',RECOMMENDED:'text-amber-700',OPTIONAL:'text-stone-500'}
export default function MovieCard({e,done,onToggle}:{e:Entry;done:boolean;onToggle:()=>void}){
 return <motion.div layout className={`glass card-hover flex gap-3 p-3 items-start ${done?'opacity-70':''}`}>
  <input type="checkbox" checked={done} onChange={onToggle} disabled={e.status!=='released'} aria-label={`Mark ${e.title} complete`} className="mt-1 h-5 w-5 accent-[#2f6f4e]"/>
  <div className="h-20 w-14 shrink-0 rounded bg-emerald-50 border border-emerald-200 text-emerald-900 grid place-items-center text-xs font-display">#{e.order}</div>
  <div className="min-w-0"><h3 className="font-semibold">{e.title}</h3>
   <p className="text-xs text-stone-500">{e.year} · {e.type} · <span className={col[e.imp]}>{e.imp}</span>{e.status==='upcoming'&&' · UNRELEASED'}{e.disputed&&' · placement debated'}</p>
   <p className="text-sm mt-1 text-stone-700">{e.desc}</p></div></motion.div>}
