import type { VercelRequest, VercelResponse } from '@vercel/node'
import { createClient } from '@supabase/supabase-js'
import { MCU } from '../src/data/mcu.js'
export default async function handler(req:VercelRequest,res:VercelResponse){
 if(req.method!=='POST')return res.status(405).end()
 const SB_URL=process.env.SUPABASE_URL??process.env.VITE_SUPABASE_URL,SB_KEY=process.env.VITE_SUPABASE_PUBLISHABLE_KEY
 if(!SB_URL||!SB_KEY||!process.env.GEMINI_API_KEY)return res.status(503).json({error:'VISHWA is not configured on the server'})
 const token=(req.headers.authorization??'').replace('Bearer ','')
 const sb=createClient(SB_URL,SB_KEY,{global:{headers:{Authorization:`Bearer ${token}`}}})
 const{data:u}=await sb.auth.getUser(token);if(!u.user)return res.status(401).json({error:'unauthorized'})
 const{data:rows}=await sb.from('watch_progress').select('content_id').eq('completed',true) // RLS: own rows only
 const done=new Set((rows??[]).map(r=>r.content_id))
 const seen=MCU.filter(e=>done.has(e.id)).map(e=>e.title),unseen=MCU.filter(e=>!done.has(e.id)&&e.status==='released')
 const next=unseen.find(e=>e.imp==='ESSENTIAL')??unseen[0]
 const system=`You are VISHWA, the witty, friendly intelligence of DOOMSDAY PROTOCOL, helping a Marvel fan prepare for Avengers: Doomsday. Explain MCU concepts simply.
SPOILER RULES: The user has completed ONLY: ${seen.join('; ')||'nothing'}. Never reveal plot details of any other title. Before any major spoiler about a completed title, warn first. Give spoiler-free summaries for the rest.
Next recommended (story order): ${next?.title??'none'}. Do not invent facts; say if unsure. Avengers: Doomsday is unreleased.`
 const history=Array.isArray(req.body.history)?req.body.history.slice(-10):[]
 const contents=[...history.map((h:any)=>({role:h.role,parts:[{text:String(h.text)}]})),{role:'user',parts:[{text:String(req.body.message).slice(0,2000)}]}]
 const model=process.env.GEMINI_MODEL??'gemini-2.5-flash'
 const r=await fetch(`https://generativelanguage.googleapis.com/v1beta/models/${model}:generateContent`,{method:'POST',headers:{'Content-Type':'application/json','x-goog-api-key':process.env.GEMINI_API_KEY!},body:JSON.stringify({systemInstruction:{parts:[{text:system}]},contents})})
 if(!r.ok)return res.status(502).json({error:'gemini'})
 const j=await r.json();res.json({reply:j.candidates?.[0]?.content?.parts?.map((p:any)=>p.text).join('')??'…'})}
