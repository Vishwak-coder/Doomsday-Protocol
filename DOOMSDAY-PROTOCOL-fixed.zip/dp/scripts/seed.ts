import { createClient } from '@supabase/supabase-js'
import { MCU } from '../src/data/mcu'
const sb=createClient(process.env.SUPABASE_URL!,process.env.SUPABASE_SERVICE_ROLE_KEY!)
const{error}=await sb.from('mcu_content').upsert(MCU.map(e=>({id:e.id,title:e.title,content_type:e.type,chronological_order:e.order,release_year:e.year,importance:e.imp,description:e.desc,release_status:e.status,placement_disputed:!!e.disputed})))
console.log(error??`Seeded ${MCU.length} entries`)
