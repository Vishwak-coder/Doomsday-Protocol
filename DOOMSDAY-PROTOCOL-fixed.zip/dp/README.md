# DOOMSDAY PROTOCOL — Every Story. Every Hero. One Final Battle. (Powered by VISHWA AI)
## Setup
1. `npm install`; copy `.env.example` to `.env.local` and fill it in (never commit it).
2. Supabase SQL editor: run `supabase/migrations/001_init.sql`.
3. `npm run seed` (needs SUPABASE_URL + SUPABASE_SERVICE_ROLE_KEY in your shell) to load the timeline.
4. Make yourself admin: run the commented `update profiles ...` line at the bottom of the migration with your email.
5. Local dev with the AI endpoint: `npx vercel dev` (plain `npm run dev` serves UI only).
## Deploy
Vercel: import repo, set the env vars from `.env.example` (server vars without VITE_), deploy.
## Admin
Run `002_admin.sql` after `001_init.sql`. Admins see /admin; data comes from `admin_*` SQL functions that return nothing to non-admins. Passwords are never exposed.
## Status
Not compiled in the authoring environment (no network). Run `npm run build` first and fix any type errors. Not yet built: per-episode UI, profile page, user detail pages, real poster art, 2026 titles.

## Vercel
Framework: Vite, build `npm run build`, output `dist` (see vercel.json). Add env vars in Settings, Environment Variables, **before** deploying: `VITE_SUPABASE_URL`, `VITE_SUPABASE_PUBLISHABLE_KEY` (build time), `GEMINI_API_KEY`, `SUPABASE_URL` (server). Changing a VITE_ variable requires a redeploy. If config is missing the app shows a "Configuration required" screen instead of a blank page.
