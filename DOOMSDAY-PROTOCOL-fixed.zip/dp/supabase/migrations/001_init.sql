create table public.profiles(id uuid primary key references auth.users on delete cascade,display_name text not null check(char_length(display_name) between 1 and 50),role text not null default 'user' check(role in('user','admin')),created_at timestamptz default now(),last_login_at timestamptz);
create table public.mcu_content(id text primary key,title text not null,content_type text not null check(content_type in('movie','series','special','animation')),chronological_order int not null,release_year int,importance text not null check(importance in('ESSENTIAL','RECOMMENDED','OPTIONAL')),description text,poster_url text,release_status text not null check(release_status in('released','upcoming')),placement_disputed boolean default false);
create table public.watch_progress(id uuid primary key default gen_random_uuid(),user_id uuid not null references public.profiles on delete cascade,content_id text not null references public.mcu_content on delete cascade,completed boolean default true,completed_at timestamptz default now(),unique(user_id,content_id));
create table public.episode_progress(id uuid primary key default gen_random_uuid(),user_id uuid not null references public.profiles on delete cascade,content_id text not null references public.mcu_content on delete cascade,season_number int not null,episode_number int not null,completed boolean default true,unique(user_id,content_id,season_number,episode_number));
create table public.activity_logs(id uuid primary key default gen_random_uuid(),user_id uuid not null references public.profiles on delete cascade,activity_type text not null,content_id text references public.mcu_content,created_at timestamptz default now());
create index on public.watch_progress(user_id);create index on public.episode_progress(user_id,content_id);create index on public.activity_logs(user_id,created_at desc);

create function public.is_admin() returns boolean language sql security definer set search_path=public stable as $$select exists(select 1 from profiles where id=auth.uid() and role='admin')$$;
create function public.handle_new_user() returns trigger language plpgsql security definer set search_path=public as $$begin insert into profiles(id,display_name) values(new.id,coalesce(nullif(new.raw_user_meta_data->>'display_name',''),split_part(new.email,'@',1)));return new;end$$;
create trigger on_auth_user_created after insert on auth.users for each row execute function public.handle_new_user();
-- last_login_at: users may not escalate role
create function public.touch_login() returns void language sql security definer set search_path=public as $$update profiles set last_login_at=now() where id=auth.uid()$$;
create function public.guard_role() returns trigger language plpgsql as $$begin if new.role<>old.role and not public.is_admin() then raise exception 'role change forbidden';end if;return new;end$$;
create trigger guard_role before update on public.profiles for each row execute function public.guard_role();

alter table profiles enable row level security;alter table mcu_content enable row level security;alter table watch_progress enable row level security;alter table episode_progress enable row level security;alter table activity_logs enable row level security;
create policy p_self on profiles for select using(id=auth.uid() or is_admin());
create policy p_upd on profiles for update using(id=auth.uid());
create policy c_read on mcu_content for select using(true);
create policy w_own on watch_progress for all using(user_id=auth.uid()) with check(user_id=auth.uid());
create policy w_admin on watch_progress for select using(is_admin());
create policy e_own on episode_progress for all using(user_id=auth.uid()) with check(user_id=auth.uid());
create policy e_admin on episode_progress for select using(is_admin());
create policy a_own on activity_logs for insert with check(user_id=auth.uid());
create policy a_read on activity_logs for select using(user_id=auth.uid() or is_admin());
-- Admin bootstrap (run once in SQL editor, with your own email; never in frontend):
-- update profiles set role='admin' where id=(select id from auth.users where email='YOUR_ADMIN_EMAIL');
