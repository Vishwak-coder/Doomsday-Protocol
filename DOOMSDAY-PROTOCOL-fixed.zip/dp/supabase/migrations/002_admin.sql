create function public.admin_overview() returns table(user_id uuid,display_name text,created_at timestamptz,last_login_at timestamptz,completed bigint,essential_completed bigint) language sql security definer set search_path=public stable as $$
 select p.id,p.display_name,p.created_at,p.last_login_at,count(w.id) filter(where w.completed),count(w.id) filter(where w.completed and c.importance='ESSENTIAL')
 from profiles p left join watch_progress w on w.user_id=p.id left join mcu_content c on c.id=w.content_id where public.is_admin() group by p.id $$;
create function public.admin_title_counts() returns table(content_id text,n bigint) language sql security definer set search_path=public stable as $$
 select content_id,count(*) from watch_progress where completed and public.is_admin() group by content_id $$;
revoke all on function public.admin_overview(),public.admin_title_counts() from public,anon;
grant execute on function public.admin_overview(),public.admin_title_counts() to authenticated;
